from project.horse_specifination.horse import Horse


class Appaloosa(Horse):
    def __init__(self, name: str, speed: int):
        super().__init__(name, speed)

    @property
    def speed(self):
        return self.__speed

    @speed.setter
    def speed(self, value):
        if value > 120:
            raise ValueError('Horse speed is too high!')

        self.__speed = value

    def train(self):
        self.speed = self.speed * 2

